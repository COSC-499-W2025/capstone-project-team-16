# Change Log
All notable changes to the "vscode-file-system-sample" extension will be documented in this file.

Check [Keep a Changelog](https://keepachangelog.com/) for recommendations on how to structure this file.

## [Unreleased]
- Initial release