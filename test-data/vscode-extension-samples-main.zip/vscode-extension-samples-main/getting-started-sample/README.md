# getting-started-sample

This sample shows how to provide a walkthrough to the Getting Started section in vscode's welcome page.

![Sample walkthrough](./media/sample.png)