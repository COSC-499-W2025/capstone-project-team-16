# Hello Windows Users

[Say hello](command:getting-started-sample.sayHello)

![Small Image](./small-image.png)

```ts
const a = 12;
```