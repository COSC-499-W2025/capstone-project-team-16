# shell-integration-sample

This sample demonstrates how to use the `Terminal.shellIntegration` extension API. It contributes a terminal profile which when launched will track the open editor and change automatically to the directory of the file being edited.
