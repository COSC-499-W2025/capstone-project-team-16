declare module '*.css' {
	const classes: Record<string, string>;
	export = classes;
}
