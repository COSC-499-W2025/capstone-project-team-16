// Trigger inline completions after each line

// [0,*):// Trigger inline completions in this line, they work!
// Trigger inline completions in this line

// [0,*):console.log(


// [0,*):console.log("foo"
// [0,*):console.log({ label: "("


// [0,*):console.log(`${(1+2}`)

// [0,*):({\n){

// [33,33):lambda x: x.notnull()
notNull = languages.apply();
