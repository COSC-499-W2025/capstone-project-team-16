export function formatProjectName(name) {
  return String(name || "").trim().replace(/\s+/g, " ");
}

export function formatContributorName(name) {
  return String(name || "").trim();
}
