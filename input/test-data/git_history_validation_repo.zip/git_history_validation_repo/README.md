# Git History Validation Repo

Small fixture repository used to validate:

- branch counting
- merge detection
- commit frequency
- contributor breakdown

It is intentionally tiny so it can be scanned quickly through the UI.
