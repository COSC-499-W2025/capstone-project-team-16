# Full Project Detail Validation Repo

This fixture is designed to exercise nearly every project-detail field shown in the scan report.

- Python and JavaScript source files
- HTML and CSS web files
- Tests, documentation, and design assets
- Node and Python dependency files
- Real Git history with two contributors, branches, and a merge

Additional implementation note for the validation fixture.
