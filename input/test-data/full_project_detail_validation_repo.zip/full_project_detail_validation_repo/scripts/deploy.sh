#!/bin/sh
echo "Deploying validation fixture"
