export function buildSummary(contributors) {
  return contributors.map((name, index) => ({
    name,
    commits: index + 1,
  }));
}

export function renderHeadline() {
  const root = document.querySelector("main");
  if (!root) return;
  root.dataset.ready = "true";
}

renderHeadline();
