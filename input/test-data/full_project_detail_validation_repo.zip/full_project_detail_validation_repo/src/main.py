from pathlib import Path


def load_message() -> str:
    return "Full detail validation fixture"


def write_report(target: Path) -> None:
    target.write_text(load_message(), encoding="utf-8")


if __name__ == "__main__":
    write_report(Path("report.txt"))
