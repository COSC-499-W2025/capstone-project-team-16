from pathlib import Path

from src.main import load_message, write_report


def test_load_message():
    assert "validation" in load_message().lower()


def test_write_report(tmp_path):
    target = tmp_path / "report.txt"
    write_report(target)
    assert target.read_text(encoding="utf-8") == "Full detail validation fixture"
