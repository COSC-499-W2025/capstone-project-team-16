# Dummy Scan Fixture

This is a small, mixed-language project fixture used to test the scanner.

- Includes Python, JS, HTML, CSS, YAML, JSON, and SQL files.
- Includes common framework/build files for detection.
