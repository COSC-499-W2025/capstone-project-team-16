#!/usr/bin/env sh
set -eu
echo "building dummy project"
